
#define BTN_PIN 4
#define LED_PIN 2   
#define POT_PIN 34   


volatile int estado = 0; 

volatile int contador_cambios = 0;
volatile bool estado_led_alerta = false;

bool ultimoEstadoBoton = HIGH;


hw_timer_t * timer = NULL;
portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

void IRAM_ATTR onTimer() {
  portENTER_CRITICAL_ISR(&mux);
  
  if (estado == 2) {
    estado_led_alerta = !estado_led_alerta; 
    digitalWrite(LED_PIN, estado_led_alerta); 
    
    contador_cambios++;
    
    if (contador_cambios >= 10) {
      estado = 0; 
      contador_cambios = 0;
      estado_led_alerta = false;
      digitalWrite(LED_PIN, LOW); 
    }
  }
  
  portEXIT_CRITICAL_ISR(&mux);
}

void setup() {
  Serial.begin(115200);

  pinMode(BTN_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);

  
  timer = timerBegin(1000000); 
  timerAttachInterrupt(timer, &onTimer);
  timerAlarm(timer, 1000000, true, 0); 

  Serial.println("\n--- FSM Robótica Iniciada ---");
  Serial.println("Estado 0: STANDBY");
}

void loop() {
 
  bool estadoBoton = digitalRead(BTN_PIN);
  
  if (estadoBoton == LOW && ultimoEstadoBoton == HIGH) {
    
    if (estado == 0) {
      estado = 1;
      Serial.println("-> Transición a Estado 1: Control Analógico");
    } 
    else if (estado == 1) {
      estado = 2;
      Serial.println("-> Transición a Estado 2: Secuencia de Alerta");
      
      portENTER_CRITICAL(&mux);
      contador_cambios = 0;
      estado_led_alerta = false;
      portEXIT_CRITICAL(&mux);
      
      analogWrite(LED_PIN, 0); 
      pinMode(LED_PIN, OUTPUT); 
      digitalWrite(LED_PIN, LOW);
    } 
    else if (estado == 2) {
      estado = 0;
      Serial.println("-> Interrupción manual. Retorno a Estado 0: STANDBY");
      
      pinMode(LED_PIN, OUTPUT); 
      digitalWrite(LED_PIN, LOW);
    }

   
    for(volatile uint32_t i=0; i<5000000; i++); 
  }
  ultimoEstadoBoton = estadoBoton;

 
  if (estado == 0) {
    digitalWrite(LED_PIN, LOW);
  } 
  else if (estado == 1) {
    int valorADC = analogRead(POT_PIN); 
    int valorPWM = map(valorADC, 0, 4095, 0, 255); 
    analogWrite(LED_PIN, valorPWM);
  }
}